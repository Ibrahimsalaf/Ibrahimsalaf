<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
}
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
include_once(ABSPATH .'wp-content/plugins/vtupress/admin/pages/users/functions.php');
$option_array = json_decode(get_option("vp_options"),true);


$banedusers = intval($wpdb->get_var("SELECT count(id) AS id FROM $userd WHERE vp_ban = 'ban' "));
$highestbal = $wpdb->get_results("SELECT MAX(vp_bal) AS vp_bal FROM $userd")[0]->vp_bal;
$highestbaluser = $wpdb->get_results("SELECT * FROM $userd ORDER BY vp_bal DESC LIMIT 10 ");
$allusers = intval($wpdb->get_var("SELECT count(id) AS id FROM $userd"));
$usersbalance = intval($wpdb->get_var("SELECT sum(vp_bal) AS vp_bal FROM $userd"));
$userswithfunds = intval($wpdb->get_var("SELECT count(id) AS vp_bal FROM $userd WHERE vp_bal > 0"));
$userswithoutfunds = intval($wpdb->get_var("SELECT count(id) AS vp_bal FROM $userd WHERE vp_bal <= 0 "));
$datapending = intval($wpdb->get_var("SELECT count(id) AS id FROM $datad WHERE status = 'Pending' "));
$withpending = intval($wpdb->get_var("SELECT count(id) AS id FROM $withd WHERE status = 'Pending' "));
$atcpending = intval($wpdb->get_var("SELECT count(id) AS id FROM $atcd WHERE status = 'pending' AND type = 'Airtime_To_Wallet'"));


//$messages = $wpdb->get_results("SELECT * FROM $messd WHERE type = 'received' AND status = 'unread' GROUP BY user_id ORDER BY id DESC LIMIT 3 ");


?>
        <div class="container-fluid dashboard-container">
          <!-- ============================================================== -->
          <!-- Sales Cards  -->
          <!-- ============================================================== -->
          <div class="row">
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-cyan text-center">
                  <h1 class="font-light text-white">
<?php
                  if(vp_option_array($option_array,'vp_security') == "yes" && vp_option_array($option_array,"secur_mod") != "off"){
                    ?>
                    <i class="fas fa-check"></i>
                    <?php
                  }
                  else{
                    ?>
                    <i class="fas fa-times"></i>
                    <?php
                  }
                  ?>
                  </h1>
                  <h6 class="text-white">Security</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-4 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-success text-center">
                  <h1 class="font-light text-white">
                 <?php echo intval($banedusers);?>
                  </h1>
                  <h6 class="text-white">Users Banned</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-warning text-center">
                  <h1 class="font-light text-white">
                   <?php echo $usersbalance;?>
                  </h1>
                  <h6 class="text-white">Users Balance</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-danger text-center">
                  <h1 class="font-light text-white">
                  <?php echo intval(vp_option_array($option_array,'vp_funds_fixed'));?>
                  </h1>
                  <h6 class="text-white">Funds Fixed</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-info text-center">
                  <h1 class="font-light text-white">
                  <?php echo intval(vp_option_array($option_array,'vp_trans_fixed'));?>
                  </h1>
                  <h6 class="text-white">Trans Fixed/Saved</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <div class="col-md-6 col-lg-4 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-danger text-center">
                  <h1 class="font-light text-white">
                    <?php echo intval($datapending);?>
                  </h1>
                  <h6 class="text-white">Data Pending History</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-warning text-center">
                  <h1 class="font-light text-white">
                    0
                  </h1>
                  <h6 class="text-white">Pending Transfers</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-info text-center">
                  <h1 class="font-light text-white">
                    <?php echo intval($allusers);?>
                  </h1>
                  <h6 class="text-white">Users</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-cyan text-center">
                  <h1 class="font-light text-white">
                    <?php echo intval($withpending);?>
                  </h1>
                  <h6 class="text-white">Pending Withdrawals</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <div class="col-md-6 col-lg-2 col-xlg-3">
              <div class="card card-hover">
                <div class="box bg-success text-center">
                  <h1 class="font-light text-white">
                    <?php echo $atcpending;?>
                  </h1>
                  <h6 class="text-white">A.T.C</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <!-- Column -->
          </div>
          <!-- ============================================================== -->
          <!-- Sales chart -->
          <!-- ============================================================== -->
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="d-md-flex align-items-center">
                    <div>
                      <h4 class="card-title">Users Analysis</h4>
                      <h5 class="card-subtitle">Top 10 users Balance</h5>
                    </div>
                  </div>
                  <div class="row">
                    <!-- column --> 
                    <div class="col-lg-9">
                      <div class="flot-chart">
                        <div
                          class="flot-chart-contentmm"
                          id="flot-line-chartmm"
                        ></div>

                        <div id="flot-placeholder" class="w-100 h-100"></div>

                      </div>
                    </div>
                    <div class="col-lg-3">
                      <div class="row">
                        <div class="col-6 mt-3"">
                          <div class="bg-dark p-10 text-white text-center">
                            <i class="mdi mdi-account fs-3 mb-1 font-16"></i><br>
                           <?php echo intval($allusers );?><br>
                            <small class="font-light">Total Users</small>
                          </div>
                        </div>
                        <div class="col-6 mt-3">
                          <div class="bg-dark p-10 text-white text-center">
                            <i class="fas fa-ban fs-3 mb-1 font-16"></i><br>
                            <?php echo intval($banedusers);?><br>
                            <small class="font-light">Banned Users</small>
                          </div>
                        </div>

                        <div class="col-6 mt-3">
                          <div class="bg-dark p-10 text-white text-center" title="User Hight Balance">
                            <i class="mdi mdi-wallet fs-3 mb-1 font-16"></i><br>
                           <?php echo intval($highestbal);?><br>
                            <small class="font-light">U.H Balance</small>
                          </div>
                        </div>
                        <div class="col-6 mt-3">
                          <div class="bg-dark p-10 text-white text-center" title="User With The Highest Balance">
                            <i class="fas fa-id-badge fs-3 mb-1 font-16"></i><br>
                            <?php
                              echo intval($highestbaluser[0]->ID);
                            ?><br>
                            <small class="font-light">User ID</small>
                          </div>
                        </div>

                        <div class="col-6 mt-3">
                          <div class="bg-dark p-10 text-white text-center">
                            <i class="fas fa-piggy-bank fs-3 mb-1 font-16"></i><br>
                            <?php echo $userswithfunds;?> <br>
                            <small class="font-light">With Funds</small>
                          </div>
                        </div>

                        <div class="col-6 mt-3">
                          <div class="bg-dark p-10 text-white text-center">
                            <i class="mdi mdi-delete-empty fs-3 mb-1 font-16"></i><br>
                            <?php echo $userswithoutfunds;?> <br>
                            <small class="font-light">Without Funds</small>
                          </div>
                        </div>
                      </div>

                    </div>
                    <!-- column -->
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- ============================================================== -->
          <!-- Sales chart -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- Recent comment and chats -->
          <!-- ============================================================== -->
          <div class="row">
            <!-- column -->
            <div class="col">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">New Messages</h4>
                </div>
                <div class="comment-widgets scrollable">
                  <!-- Comment Row -->
                  <div class="d-flex flex-row comment-row mt-0">

<?php
                  foreach($messages as $message){
?>
                    <div class="p-2">
                      <img
                        src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/users/1.jpg"
                        alt="user"
                        width="50"
                        class="rounded-circle"
                      /> 
                </div>

<div class="comment-text w-100">
                      <h6 class="font-medium"><?php echo ucfirst($message->name);?></h6>
                      <span class="mb-3 d-block"
                        ><?php echo substr($message->message,0,30);?>
                      </span>
                      <div class="comment-footer">
                        <span class="text-muted float-end"><?php echo $message->the_time;?></span>
                       <a href="?page=vtupanel&adminpage=messages&user_id=<?php echo $message->user_id;?>"class="btn"> <button
                          type="button"
                          class="btn btn-cyan btn-sm text-white"
                        >
                          Read
                        </button></a>
                      </div>
  </div>

<?php
                  }
?>



                  </div>
                  <!-- Comment Row -->
                </div>
              </div>
              <!-- Card -->

              <!-- card -->
              <!-- card new HIDDEN USER NOTIFICATION -->
              <div class="card d-none">
                <div class="card-body">
                  <h4 class="card-title mb-0">Users Notifications</h4>
                </div>
                <ul class="list-style-none">
                  <li class="d-flex no-block card-body">
                    <i class="mdi mdi-check-circle fs-4 w-30px mt-1"></i>
                    <div>
                      <a href="#" class="mb-0 font-medium p-0"
                        >Lorem ipsum dolor sit amet, consectetur adipiscing
                        elit.</a
                      >
                      <span class="text-muted"
                        >dolor sit amet, consectetur adipiscing</span
                      >
                    </div>
                    <div class="ms-auto">
                      <div class="tetx-right">
                        <h5 class="text-muted mb-0">20</h5>
                        <span class="text-muted font-16">Jan</span>
                      </div>
                    </div>
                  </li>
                  <li class="d-flex no-block card-body border-top">
                    <i class="mdi mdi-gift fs-4 w-30px mt-1"></i>
                    <div>
                      <a href="#" class="mb-0 font-medium p-0"
                        >Congratulation Maruti, Happy Birthday</a
                      >
                      <span class="text-muted"
                        >many many happy returns of the day</span
                      >
                    </div>
                    <div class="ms-auto">
                      <div class="tetx-right">
                        <h5 class="text-muted mb-0">11</h5>
                        <span class="text-muted font-16">Jan</span>
                      </div>
                    </div>
                  </li>
                  <li class="d-flex no-block card-body border-top">
                    <i class="mdi mdi-plus fs-4 w-30px mt-1"></i>
                    <div>
                      <a href="#" class="mb-0 font-medium p-0"
                        >Maruti is a Responsive Admin theme</a
                      >
                      <span class="text-muted"
                        >But already everything was solved. It will ...</span
                      >
                    </div>
                    <div class="ms-auto">
                      <div class="tetx-right">
                        <h5 class="text-muted mb-0">19</h5>
                        <span class="text-muted font-16">Jan</span>
                      </div>
                    </div>
                  </li>
                  <li class="d-flex no-block card-body border-top">
                    <i class="mdi mdi-leaf fs-4 w-30px mt-1"></i>
                    <div>
                      <a href="#" class="mb-0 font-medium p-0"
                        >Envato approved Maruti Admin template</a
                      >
                      <span class="text-muted"
                        >i am very happy to approved by TF</span
                      >
                    </div>
                    <div class="ms-auto">
                      <div class="tetx-right">
                        <h5 class="text-muted mb-0">20</h5>
                        <span class="text-muted font-16">Jan</span>
                      </div>
                    </div>
                  </li>
                  <li class="d-flex no-block card-body border-top">
                    <i
                      class="mdi mdi-comment-question-outline fs-4 w-30px mt-1"
                    ></i>
                    <div>
                      <a href="#" class="mb-0 font-medium p-0">
                        I am alwayse here if you have any question</a
                      >
                      <span class="text-muted"
                        >we glad that you choose our template</span
                      >
                    </div>
                    <div class="ms-auto">
                      <div class="tetx-right">
                        <h5 class="text-muted mb-0">15</h5>
                        <span class="text-muted font-16">Jan</span>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <!-- column -->
              <!-- card new HIDDEN CHATs -->
            <div class="col-lg-6 d-none">
              <!-- Card -->
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Chat Option</h4>
                  <div class="chat-box scrollable" style="height: 475px">
                    <!--chat Row -->
                    <ul class="chat-list">

                      <!--chat Row  RECEIVED-->
                      <li class="chat-item d-none">
                        <div class="chat-img">
                          <img src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/users/1.jpg" alt="user" />
                        </div>
                        <div class="chat-content">
                          <h6 class="font-medium">James Anderson</h6>
                          <div class="box bg-light-info">
                            Lorem Ipsum is simply dummy text of the printing
                            &amp; type setting industry.
                          </div>
                        </div>
                        <div class="chat-time">10:56 am</div>
                      </li>
                      <!--chat Row SEND-->
                      <li class="odd chat-item d-none">
                        <div class="chat-content">
                          <div class="box bg-light-inverse">
                            I would love to join the team.
                          </div>
                          <br />
                        </div>
                      </li>
                    <?php
                        

                    ?>


                    </ul>
                  </div>
                </div>
                <div class="card-body border-top">
                  <div class="row">
                    <div class="col-9">
                      <div class="input-field mt-0 mb-0">
                        <textarea
                          id="textarea1"
                          placeholder="Type and enter"
                          class="form-control border-0"
                        ></textarea>
                      </div>
                    </div>
                    <div class="col-3">
                      <a
                        class="btn-circle btn-lg btn-cyan float-end text-white"
                        href="javascript:void(0)"
                        ><i class="mdi mdi-send fs-3"></i
                      ></a>
                    </div>
                  </div>
                </div>
              </div>
              <!-- card  HIDDEN NEED HELP?-->
              <div class="card d-none">
                <div class="card-body">
                  <h4 class="card-title">Need Help?</h4>
                </div>
                <div
                  class="comment-widgets scrollable"
                  style="max-height: 130px"
                >
                  <!-- Comment Row -->
                  <div class="d-flex flex-row comment-row mt-0">
                    <div class="p-2">
                      <img
                        src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/users/1.jpg"
                        alt="user"
                        width="50"
                        class="rounded-circle"
                      />
                    </div>
                    <div class="comment-text w-100">
                      <h6 class="font-medium">VTUPRESS MESSAGE!</h6>
                      <span class="mb-3 d-block"
                        >
                        Should you have issues with this plugin? kindly Join Our Telegram Group!!!
                      </span>
                      <div class="comment-footer">
                        <span class="text-muted float-end">C.E.O Akor Victor</span>
                        <button
                          type="button"
                          class="btn btn-cyan btn-sm text-white"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          class="btn btn-success btn-sm text-white"
                        >
                          Publish
                        </button>
                        <button
                          type="button"
                          class="btn btn-danger btn-sm text-white"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                  <!-- Comment Row -->
                  <div class="d-flex flex-row comment-row">
                    <div class="p-2">
                      <img
                        src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/users/4.jpg"
                        alt="user"
                        width="50"
                        class="rounded-circle"
                      />
                    </div>
                    <div class="comment-text active w-100">
                      <h6 class="font-medium">Michael Jorden</h6>
                      <span class="mb-3 d-block"
                        >Lorem Ipsum is simply dummy text of the printing and
                        type setting industry.
                      </span>
                      <div class="comment-footer">
                        <span class="text-muted float-end">May 10, 2021</span>
                        <button
                          type="button"
                          class="btn btn-cyan btn-sm text-white"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          class="btn btn-success btn-sm text-white"
                        >
                          Publish
                        </button>
                        <button
                          type="button"
                          class="btn btn-danger btn-sm text-white"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                  <!-- Comment Row -->
                  <div class="d-flex flex-row comment-row">
                    <div class="p-2">
                      <img
                        src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/users/5.jpg"
                        alt="user"
                        width="50"
                        class="rounded-circle"
                      />
                    </div>
                    <div class="comment-text w-100">
                      <h6 class="font-medium">Johnathan Doeting</h6>
                      <span class="mb-3 d-block"
                        >Lorem Ipsum is simply dummy text of the printing and
                        type setting industry.
                      </span>
                      <div class="comment-footer">
                        <span class="text-muted float-end">August 1, 2021</span>
                        <button
                          type="button"
                          class="btn btn-cyan btn-sm text-white"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          class="btn btn-success btn-sm text-white"
                        >
                          Publish
                        </button>
                        <button
                          type="button"
                          class="btn btn-danger btn-sm text-white"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- accoridan part -->

              <!-- toggle part -->

              <!-- Tabs HIDDEN TABS1 - 3-->
              <div class="card d-none">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a
                      class="nav-link active"
                      data-bs-toggle="tab"
                      href="#home"
                      role="tab"
                      ><span class="hidden-sm-up"></span>
                      <span class="hidden-xs-down">Tab1</span></a
                    >
                  </li>
                  <li class="nav-item">
                    <a
                      class="nav-link"
                      data-bs-toggle="tab"
                      href="#profile"
                      role="tab"
                      ><span class="hidden-sm-up"></span>
                      <span class="hidden-xs-down">Tab2</span></a
                    >
                  </li>
                  <li class="nav-item">
                    <a
                      class="nav-link"
                      data-bs-toggle="tab"
                      href="#messages"
                      role="tab"
                      ><span class="hidden-sm-up"></span>
                      <span class="hidden-xs-down">Tab3</span></a
                    >
                  </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content tabcontent-border">
                  <div class="tab-pane active" id="home" role="tabpanel">
                    <div class="p-20">
                      <p>
                        And is full of waffle to It has multiple paragraphs and
                        is full of waffle to pad out the comment. Usually, you
                        just wish these sorts of comments would come to an
                        end.multiple paragraphs and is full of waffle to pad out
                        the comment..
                      </p>
                      <img
                        src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/background/img4.jpg"
                        class="img-fluid"
                      />
                    </div>
                  </div>
                  <div class="tab-pane p-20" id="profile" role="tabpanel">
                    <div class="p-20">
                      <img
                        src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/background/img4.jpg"
                        class="img-fluid"
                      />
                      <p class="mt-2">
                        And is full of waffle to It has multiple paragraphs and
                        is full of waffle to pad out the comment. Usually, you
                        just wish these sorts of comments would come to an
                        end.multiple paragraphs and is full of waffle to pad out
                        the comment..
                      </p>
                    </div>
                  </div>
                  <div class="tab-pane p-20" id="messages" role="tabpanel">
                    <div class="p-20">
                      <p>
                        And is full of waffle to It has multiple paragraphs and
                        is full of waffle to pad out the comment. Usually, you
                        just wish these sorts of comments would come to an
                        end.multiple paragraphs and is full of waffle to pad out
                        the comment..
                      </p>
                      <img
                        src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/images/background/img4.jpg"
                        class="img-fluid"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
          <!-- ============================================================== -->
          <!-- Recent comment and chats -->
          <!-- ============================================================== -->


    <script src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/libs/flot/excanvas.js"></script>
    <script src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/libs/flot/jquery.flot.js"></script>
    <script src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/libs/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/libs/flot/jquery.flot.time.js"></script>
    <script src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/libs/flot/jquery.flot.stack.js"></script>
    <script src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/libs/flot/jquery.flot.crosshair.js"></script>
    <script src="<?php echo esc_url(plugins_url("vtupress/admin")); ?>/assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>

    <script type="text/javascript">
 var data = [     <?php
foreach($highestbaluser as $usar){
$id = $usar->ID;
$bal = $usar->vp_bal;
echo "[$id, $bal],";
}

?>
];
       // , [2, 40], [3, 80], [4, 160], [5, 159], [6, 370], [7, 330], [8, 350], [9, 370], [10, 400], [11, 330], [12, 350]
 
        var dataset = [{label: "line1",data: data}];
 
        var options = {
            series: {
                lines: { show: true },
                points: {
                    radius: 3,
                    show: true
                }
            }
        };
 
        jQuery(document).ready(function () {
            jQuery.plot(jQuery("#flot-placeholder"), dataset, options);
        });
    </script>

</div>