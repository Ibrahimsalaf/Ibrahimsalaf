<?php
function pagination_fwebhook($where=""){
	  
   global  $wpdb, $result;
  
  
  $limit = isset($_REQUEST["limit-records"]) ? $_REQUEST["limit-records"] : 10;
  $page = isset($_GET['transpage']) ? $_GET['transpage'] : 1;
  $start = ($page - 1) * $limit;
  
  
      $table_name = $wpdb->prefix."vp_wallet_webhook";
  
      $use = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");

      if($use == null){
       $result = "null";
      }
      else{
       $result = $use;


      $num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
      $pages = ceil( $num  / $limit );
      
      $Previous = $page - 1;
      $Next = $page + 1;
      echo '

      <div class="row">
      <div class="col-12 col-md-4">
<div class="input-group">
<span class="input-group-text">Page</span>
<select class="change-page float-left" onchange="changepage();">
        ';
for($i = 1; $i<= $pages; $i++){
if(isset($_GET["transpage"]) && $_GET["transpage"] == $i){
   echo'
   <option value="'.$i.'" disabled selected  class="opt" >'.$i.'<option>
   ';
    }elseif(empty($i)){

    }
    else{
       echo'
       <option value="'.$i.'" class="opt" >'.$i.'<option>
       ';
    }

}
  echo'
  </select>
  <script>
  jQuery(".change-page option:not(.opt)").hide();
  </script>
  </div>
  </div>

  <div class="col-12 col-md-4">

<div class="input-group justify-content-end">
<span class="input-group-text">Limit</span>
<select class="change-limit" onchange="changelimit();">
                          ';
                          
foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
if( isset($_GET["limit-records"]) && $_GET["limit-records"] == $limit){
$echo = "selected disabled";
}
else{
$echo = "opt";
}
echo'
<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
';
}
echo'
</select>
</div>
</div>
</div>

';

?>

<script>
function changelimit(){
var limit = jQuery(".change-limit").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&limit-records="+limit;

}
function changepage(){
var transpage = jQuery(".change-page").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&transpage="+transpage;

}
</script>

<?php


}
}


function pagination_webhook($where=""){
	  
   global  $wpdb, $result;
  
  
  $limit = isset($_REQUEST["limit-records"]) ? $_REQUEST["limit-records"] : 10;
  $page = isset($_GET['transpage']) ? $_GET['transpage'] : 1;
  $start = ($page - 1) * $limit;
  
  
      $table_name = $wpdb->prefix."vpwebhook";
  
      $use = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");

      if($use == null){
       $result = "null";
      }
      else{
       $result = $use;


      $num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
      $pages = ceil( $num  / $limit );
      
      $Previous = $page - 1;
      $Next = $page + 1;
      echo '

      <div class="row">
      <div class="col-12 col-md-4">
<div class="input-group">
<span class="input-group-text">Page</span>
<select class="change-page float-left" onchange="changepage();">
        ';
for($i = 1; $i<= $pages; $i++){
if(isset($_GET["transpage"]) && $_GET["transpage"] == $i){
   echo'
   <option value="'.$i.'" disabled selected  class="opt" >'.$i.'<option>
   ';
    }elseif(empty($i)){

    }
    else{
       echo'
       <option value="'.$i.'" class="opt" >'.$i.'<option>
       ';
    }

}
  echo'
  </select>
  <script>
  jQuery(".change-page option:not(.opt)").hide();
  </script>
  </div>
  </div>

  <div class="col-12 col-md-4">

<div class="input-group justify-content-end">
<span class="input-group-text">Limit</span>
<select class="change-limit" onchange="changelimit();">
                          ';
                          
foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
if( isset($_GET["limit-records"]) && $_GET["limit-records"] == $limit){
$echo = "selected disabled";
}
else{
$echo = "opt";
}
echo'
<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
';
}
echo'
</select>
</div>
</div>
</div>

';

?>

<script>
function changelimit(){
var limit = jQuery(".change-limit").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&limit-records="+limit;

}
function changepage(){
var transpage = jQuery(".change-page").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&transpage="+transpage;

}
</script>

<?php


}
}



function pagination_history_before($db="",$status="true",$whe=""){
	  
   global  $wpdb, $transactions;
  if($status == "true"){
   $stat = "status = 'successful'";
   $where = "WHERE $stat ".$whe;
  }
  elseif($status == "fa"){
   $stat = "status = 'fa'";
   $where = "WHERE $stat ".$whe;

  }
  elseif($status == "false"){
   $stat = "status = 'Pending'";
   $where = "WHERE $stat ".$whe;

  }
  else{
   $stat = "status = 'Failed'";
   $where = "WHERE $stat ".$whe;
  }
  
  $limit = isset($_REQUEST["limit-records"]) ? $_REQUEST["limit-records"] : 10;
  $page = isset($_GET['transpage']) ? $_GET['transpage'] : 1;
  $start = ($page - 1) * $limit;
  
  
      $table_name = $wpdb->prefix.$db;
  
      $use = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");

      if($use == null){
       $transactions = "null";
      }
      else{
       $transactions = $use;


      $num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
      $pages = ceil( $num  / $limit );
      
      $Previous = $page - 1;
      $Next = $page + 1;
      echo '

      <div class="row">
      <div class="col-12 col-md-4">
<div class="input-group">
<span class="input-group-text">Page</span>
<select class="change-page float-left" onchange="changepage();">
        ';
for($i = 1; $i<= $pages; $i++){
if(isset($_GET["transpage"]) && $_GET["transpage"] == $i){
   echo'
   <option value="'.$i.'" disabled selected  class="opt" >'.$i.'<option>
   ';
    }elseif(empty($i)){

    }
    else{
       echo'
       <option value="'.$i.'" class="opt" >'.$i.'<option>
       ';
    }

}
  echo'
  </select>
  <script>
  jQuery(".change-page option:not(.opt)").hide();
  </script>
  </div>
  </div>

<div class="col-12 col-md-4">

<div class="input-group">
<input class="form-control border-end-0 border rounded-pill search-trans" type="search" placeholder="search" id="example-search-input">
<span class="input-group-append">
   <button onclick="searchtrans(jQuery(\'.search-trans\').val())" class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" type="button">
       <i class="fa fa-search"></i>
   </button>
</span>
</div>
<script>
function searchtrans(val){
location.href = "'.$_SERVER["REQUEST_URI"].'&trans_id="+val;
}
</script>
</div>

  <div class="col-12 col-md-4">

<div class="input-group justify-content-start">
<span class="input-group-text">Limit</span>
<select class="change-limit" onchange="changelimit();">
                          ';
                          
foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
if( isset($_GET["limit-records"]) && $_GET["limit-records"] == $limit){
$echo = "selected disabled";
}
else{
$echo = "opt";
}
echo'
<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
';
}
echo'
</select>
</div>
</div>
</div>

';

?>

<script>
function changelimit(){
var limit = jQuery(".change-limit").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&limit-records="+limit;

}
function changepage(){
var transpage = jQuery(".change-page").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&transpage="+transpage;

}
</script>

<?php


}
}






function pagination_withdrawal_before($db="",$status="true",$whe=""){
	  
   global  $wpdb, $transactions;
  if($status == "true"){
   $stat = "status = 'Approved'";
   $where = "WHERE $stat ".$whe;
  }
  elseif($status == "false"){
   $stat = "status = 'Pending'";
   $where = "WHERE $stat ".$whe;
  }
  else{
   $stat = "status = 'failed'";
   $where = "WHERE $stat ".$whe;
  }
  
  $limit = isset($_REQUEST["limit-records"]) ? $_REQUEST["limit-records"] : 10;
  $page = isset($_GET['transpage']) ? $_GET['transpage'] : 1;
  $start = ($page - 1) * $limit;
  
  
      $table_name = $wpdb->prefix.$db;
  
      $use = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");

      if($use == null){
       $transactions = "null";
      }
      else{
       $transactions = $use;


      $num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
      $pages = ceil( $num  / $limit );
      
      $Previous = $page - 1;
      $Next = $page + 1;
      echo '

      <div class="row">
      <div class="col-12 col-md-4">
<div class="input-group">
<span class="input-group-text">Page</span>
<select class="change-page float-left" onchange="changepage();">
        ';
for($i = 1; $i<= $pages; $i++){
if(isset($_GET["transpage"]) && $_GET["transpage"] == $i){
   echo'
   <option value="'.$i.'" disabled selected  class="opt" >'.$i.'<option>
   ';
    }elseif(empty($i)){

    }
    else{
       echo'
       <option value="'.$i.'" class="opt" >'.$i.'<option>
       ';
    }

}
  echo'
  </select>
  <script>
  jQuery(".change-page option:not(.opt)").hide();
  </script>
  </div>
  </div>

<div class="col-12 col-md-4">

<div class="input-group">
<input class="form-control border-end-0 border rounded-pill search-trans" type="search" placeholder="search" id="example-search-input">
<span class="input-group-append">
   <button onclick="searchtrans(jQuery(\'.search-trans\').val())" class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" type="button">
       <i class="fa fa-search"></i>
   </button>
</span>
</div>
<script>
function searchtrans(val){
location.href = "'.$_SERVER["REQUEST_URI"].'&trans_id="+val;
}
</script>
</div>

  <div class="col-12 col-md-4">

<div class="input-group justify-content-start">
<span class="input-group-text">Limit</span>
<select class="change-limit" onchange="changelimit();">
                          ';
                          
foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
if( isset($_GET["limit-records"]) && $_GET["limit-records"] == $limit){
$echo = "selected disabled";
}
else{
$echo = "opt";
}
echo'
<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
';
}
echo'
</select>
</div>
</div>
</div>

';

?>

<script>
function changelimit(){
var limit = jQuery(".change-limit").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&limit-records="+limit;

}
function changepage(){
var transpage = jQuery(".change-page").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&transpage="+transpage;

}
</script>

<?php


}
}



function pagination_conversion_before($status="true",$whe=""){
	  
   global  $wpdb, $transactions;
  if($status == "true"){
   $stat = "status = 'pending' AND (type = 'Airtime_To_Wallet' OR type = 'Airtime_To_Cash')";
   $where = "WHERE $stat ".$whe;
  }
  elseif($status == "false"){
   $stat = "status = 'Approved' AND (type = 'Airtime_To_Wallet' OR type = 'Airtime_To_Cash') ";
   $where = "WHERE $stat ".$whe;
  }
  else{
   $stat = "status = 'Failed' AND (type = 'Airtime_To_Wallet' OR type = 'Airtime_To_Cash') ";
   $where = "WHERE $stat ".$whe;
  }
 

  
  $limit = isset($_REQUEST["limit-records"]) ? $_REQUEST["limit-records"] : 10;
  $page = isset($_GET['transpage']) ? $_GET['transpage'] : 1;
  $start = ($page - 1) * $limit;
  
  
      $table_name = $wpdb->prefix."vp_wallet";
  
      $use = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");

      if($use == null){
       $transactions = "null";
      }
      else{
       $transactions = $use;


      $num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
      $pages = ceil( $num  / $limit );
      
      $Previous = $page - 1;
      $Next = $page + 1;
      echo '

      <div class="row">
      <div class="col-12 col-md-4">
<div class="input-group">
<span class="input-group-text">Page</span>
<select class="change-page float-left" onchange="changepage();">
        ';
for($i = 1; $i<= $pages; $i++){
if(isset($_GET["transpage"]) && $_GET["transpage"] == $i){
   echo'
   <option value="'.$i.'" disabled selected  class="opt" >'.$i.'<option>
   ';
    }elseif(empty($i)){

    }
    else{
       echo'
       <option value="'.$i.'" class="opt" >'.$i.'<option>
       ';
    }

}
  echo'
  </select>
  <script>
  jQuery(".change-page option:not(.opt)").hide();
  </script>
  </div>
  </div>

<div class="col-12 col-md-4">

<div class="input-group">
<input class="form-control border-end-0 border rounded-pill search-trans" type="search" placeholder="search" id="example-search-input">
<span class="input-group-append">
   <button onclick="searchtrans(jQuery(\'.search-trans\').val())" class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" type="button">
       <i class="fa fa-search"></i>
   </button>
</span>
</div>
<script>
function searchtrans(val){
location.href = "'.$_SERVER["REQUEST_URI"].'&trans_id="+val;
}
</script>
</div>

  <div class="col-12 col-md-4">

<div class="input-group justify-content-start">
<span class="input-group-text">Limit</span>
<select class="change-limit" onchange="changelimit();">
                          ';
                          
foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
if( isset($_GET["limit-records"]) && $_GET["limit-records"] == $limit){
$echo = "selected disabled";
}
else{
$echo = "opt";
}
echo'
<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
';
}
echo'
</select>
</div>
</div>
</div>

';

?>

<script>
function changelimit(){
var limit = jQuery(".change-limit").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&limit-records="+limit;

}
function changepage(){
var transpage = jQuery(".change-page").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&transpage="+transpage;

}
</script>

<?php


}
}








function pagination_transfer_before($status="true",$whe=""){
	  
   global  $wpdb, $transactions;
  if($status == "true"){
   $stat = "status = 'pending'";
   $where = "WHERE $stat ".$whe;
  }
  elseif($status == "false"){
   $stat = "status = 'Approved'";
   $where = "WHERE $stat ".$whe;
  }
  else{
   $stat = "status = 'Failed'";
   $where = "WHERE $stat ".$whe;
  }
 

  
  $limit = isset($_REQUEST["limit-records"]) ? $_REQUEST["limit-records"] : 10;
  $page = isset($_GET['transpage']) ? $_GET['transpage'] : 1;
  $start = ($page - 1) * $limit;
  
  
      $table_name = $wpdb->prefix."vp_transfer";
  
      $use = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");

      if($use == null){
       $transactions = "null";
      }
      else{
       $transactions = $use;


      $num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
      $pages = ceil( $num  / $limit );
      
      $Previous = $page - 1;
      $Next = $page + 1;
      echo '

      <div class="row">
      <div class="col-12 col-md-4">
<div class="input-group">
<span class="input-group-text">Page</span>
<select class="change-page float-left" onchange="changepage();">
        ';
for($i = 1; $i<= $pages; $i++){
if(isset($_GET["transpage"]) && $_GET["transpage"] == $i){
   echo'
   <option value="'.$i.'" disabled selected  class="opt" >'.$i.'<option>
   ';
    }elseif(empty($i)){

    }
    else{
       echo'
       <option value="'.$i.'" class="opt" >'.$i.'<option>
       ';
    }

}
  echo'
  </select>
  <script>
  jQuery(".change-page option:not(.opt)").hide();
  </script>
  </div>
  </div>

<div class="col-12 col-md-4">

<div class="input-group">
<input class="form-control border-end-0 border rounded-pill search-trans" type="search" placeholder="search" id="example-search-input">
<span class="input-group-append">
   <button onclick="searchtrans(jQuery(\'.search-trans\').val())" class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" type="button">
       <i class="fa fa-search"></i>
   </button>
</span>
</div>
<script>
function searchtrans(val){
location.href = "'.$_SERVER["REQUEST_URI"].'&trans_id="+val;
}
</script>
</div>

  <div class="col-12 col-md-4">

<div class="input-group justify-content-start">
<span class="input-group-text">Limit</span>
<select class="change-limit" onchange="changelimit();">
                          ';
                          
foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
if( isset($_GET["limit-records"]) && $_GET["limit-records"] == $limit){
$echo = "selected disabled";
}
else{
$echo = "opt";
}
echo'
<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
';
}
echo'
</select>
</div>
</div>
</div>

';

?>

<script>
function changelimit(){
var limit = jQuery(".change-limit").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&limit-records="+limit;

}
function changepage(){
var transpage = jQuery(".change-page").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&transpage="+transpage;

}
</script>

<?php


}
}







function pagination_wallet_before($whe=""){
	  
   global  $wpdb, $transactions;

  
  $limit = isset($_REQUEST["limit-records"]) ? $_REQUEST["limit-records"] : 10;
  $page = isset($_GET['transpage']) ? $_GET['transpage'] : 1;
  $start = ($page - 1) * $limit;
  
  
      $table_name = $wpdb->prefix."vp_wallet";
  
      $use = $wpdb->get_results("SELECT * FROM  $table_name $whe ORDER BY ID DESC LIMIT $start, $limit");

      if($use == null){
       $transactions = "null";
      }
      else{
       $transactions = $use;


      $num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $whe");
      $pages = ceil( $num  / $limit );
      
      $Previous = $page - 1;
      $Next = $page + 1;
      echo '

      <div class="row">
      <div class="col-12 col-md-4">
<div class="input-group">
<span class="input-group-text">Page</span>
<select class="change-page float-left" onchange="changepage();">
        ';
for($i = 1; $i<= $pages; $i++){
if(isset($_GET["transpage"]) && $_GET["transpage"] == $i){
   echo'
   <option value="'.$i.'" disabled selected  class="opt" >'.$i.'<option>
   ';
    }elseif(empty($i)){

    }
    else{
       echo'
       <option value="'.$i.'" class="opt" >'.$i.'<option>
       ';
    }

}
  echo'
  </select>
  <script>
  jQuery(".change-page option:not(.opt)").hide();
  </script>
  </div>
  </div>

<div class="col-12 col-md-4">

<div class="input-group">
<input class="form-control border-end-0 border rounded-pill search-trans" type="search" placeholder="search" id="example-search-input">
<span class="input-group-append">
   <button onclick="searchtrans(jQuery(\'.search-trans\').val())" class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" type="button">
       <i class="fa fa-search"></i>
   </button>
</span>
</div>
<script>
function searchtrans(val){
location.href = "'.$_SERVER["REQUEST_URI"].'&trans_id="+val;
}
</script>
</div>

  <div class="col-12 col-md-4">

<div class="input-group justify-content-start">
<span class="input-group-text">Limit</span>
<select class="change-limit" onchange="changelimit();">
                          ';
                          
foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
if( isset($_GET["limit-records"]) && $_GET["limit-records"] == $limit){
$echo = "selected disabled";
}
else{
$echo = "opt";
}
echo'
<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
';
}
echo'
</select>
</div>
</div>
</div>

';

?>

<script>
function changelimit(){
var limit = jQuery(".change-limit").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&limit-records="+limit;

}
function changepage(){
var transpage = jQuery(".change-page").val();

window.location = "<?php echo $_SERVER["REQUEST_URI"];?>&transpage="+transpage;

}
</script>

<?php


}
}?>