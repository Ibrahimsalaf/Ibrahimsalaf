<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
}
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");


if(isset($_REQUEST["action"])){
    global $wpdb;

    $action = $_REQUEST["action"];

    $sids = $_REQUEST["trans_id"];
    $table = $_REQUEST["table"];
    $type = $_REQUEST["type"];
    
    $name = get_userdata(get_current_user_id())->user_login;
    
    switch($_REQUEST["action"]){



        case"reverse":
            $explode = explode(",",$sids);
        foreach($explode as $sida){
if(!empty($sida)){
            $sid = explode("-",$sida)[0];
            $amount = explode("-",$sida)[1];
            $id = explode("-",$sida)[2];
            //set status to failed
            
            $data = [ 'status' => 'Failed' ];
            $where = [ 'id' => $sid ];
            $updated = $wpdb->update( $wpdb->prefix.$table, $data, $where);
            
            //credit the user
            $before_amount = floatval(vp_getuser($id,"vp_bal",true))+0.1;
            $now_amount = $before_amount + $amount;
            
            vp_updateuser($id, "vp_bal", $now_amount);
            
            
            //notify user about the update
            $table_name = $wpdb->prefix.'vp_wallet';
            $wpdb->insert($table_name, array(
            'name'=> $name,
            'type'=> "Wallet",
            'description'=> "Reversal For $type Transaction With ID $sid",
            'fund_amount' => $amount,
            'before_amount' => $before_amount,
            'now_amount' => $now_amount,
            'user_id' => $id,
            'status' => "Approved",
            'the_time' => date('Y-m-d h:i:s A')
            ));
            

        }

    }
        

die("100");

        break;

        case"delete":

            $explode = explode(",",$sids);
        foreach($explode as $sida){
if(!empty($sida)){
            $sid = explode("-",$sida)[0];
            //set status to failed
            

            $wpdb->delete($wpdb->prefix.$table, array('id' => $sid));
            

        }

    }
        

die("100");

        break;

        case"success":

                $explode = explode(",",$sids);
                foreach($explode as $sida){
        if(!empty($sida)){
                    $sid = explode("-",$sida)[0];
                    //set status to failed
                        //set status to failed
    $data = [ 'status' => 'Successful' ];
    $where = [ 'id' => $sid ];
    $updated = $wpdb->update( $wpdb->prefix.$table, $data, $where);
                    
        
                    
        
                }
        
            }

    
    die("100");
            break;	
  
        
    

}
}
elseif(isset($_REQUEST["process_with"])){
	
	global $wpdb;
	
	$dothis = $_REQUEST["process_with"];
	$forthis = $_REQUEST["with_user_id"];
	$amount = $_REQUEST["with_amount"];
	$row = $_REQUEST["the_row_id"];
	
	if($dothis == "Approve"){
		$update = "Approved";
		$cur = vp_getuser($forthis,'vp_bal',true);
		$tot = $cur + $amount;
		vp_updateuser($forthis,'vp_bal',$tot);
	}
	elseif($dothis == "Fail"){
		$update = "failed";
	
	}
	else{
		$update = "Processing";
	}
	
$data = [ 'status' => $update ];
$where = [ 'id' => $row ];
$updated = $wpdb->update( $wpdb->prefix.'vp_withdrawal', $data, $where);

if($updated !== false){
echo'100';
}
else{
echo'200';	
}

}elseif(isset($_REQUEST['convert_to'])){
	$convert_to = $_REQUEST["convert_to"];
	$convert_id = $_REQUEST["convert_id"];
	$convert_user_id = $_REQUEST["convert_user_id"];
	$convert_amount = $_REQUEST["convert_amount"];
	

		global $wpdb;
if(strtolower($convert_to) == "approve"){
		$update = "Approved";
$before_amount = vp_getuser($convert_user_id,"vp_bal",true);
$now_amount = $before_amount + $convert_amount;
vp_updateuser($convert_user_id, "vp_bal", $now_amount);
	}
	else{
		$update = "Failed";
	}
	
$data = [ 'status' => $update ];
$where = [ 'id' => $convert_id ];
$updated = $wpdb->update( $wpdb->prefix.'vp_wallet', $data, $where);


if($updated !== false){
die("100");
}
else{
die("Error!!!");
}

	
	
}?>    