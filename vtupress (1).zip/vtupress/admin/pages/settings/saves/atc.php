<?php
header("Access-Control-Allow-Origin: *");
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
}
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
vp_updateoption('airtime_to_wallet', $_REQUEST['airtime_to_wallet']);
vp_updateoption('airtime_to_cash', $_REQUEST['airtime_to_cash']);
vp_updateoption('mtn_airtime', $_REQUEST['mtn_airtime']);
vp_updateoption('glo_airtime', $_REQUEST['glo_airtime']);
vp_updateoption('airtel_airtime', $_REQUEST['airtel_airtime']);
vp_updateoption('9mobile_airtime', $_REQUEST['9mobile_airtime']);
vp_updateoption('airtime_to_cash_charge', $_REQUEST['airtime_to_cash_charge']);
vp_updateoption('airtime_to_wallet_charge', $_REQUEST['airtime_to_wallet_charge']);

vp_updateoption('aairtime_to_cash_charge', $_REQUEST['aairtime_to_cash_charge']);
vp_updateoption('aairtime_to_wallet_charge', $_REQUEST['aairtime_to_wallet_charge']);

vp_updateoption('9airtime_to_cash_charge', $_REQUEST['9airtime_to_cash_charge']);
vp_updateoption('9airtime_to_wallet_charge', $_REQUEST['9airtime_to_wallet_charge']);

vp_updateoption('gairtime_to_cash_charge', $_REQUEST['gairtime_to_cash_charge']);
vp_updateoption('gairtime_to_wallet_charge', $_REQUEST['gairtime_to_wallet_charge']);

die("100");
?>