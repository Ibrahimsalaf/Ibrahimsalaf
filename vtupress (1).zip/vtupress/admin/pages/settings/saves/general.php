<?php
header("Access-Control-Allow-Origin: 'self'");
//header("Access-Control-Allow-Methods: POST, GET");
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
}
else{
include_once(ABSPATH ."wp-load.php");
}
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH.'wp-admin/includes/plugin.php');
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');


if(isset($_REQUEST["fset"])){

    vp_updateoption("vpdebug", trim($_REQUEST["vpdebug"]));
    if(vp_getoption("vp_security") == "yes"){
    vp_updateoption("auto_transfer", trim($_REQUEST["auto_transfer"]));
    }
    vp_updateoption("vp_enable_registration", trim($_REQUEST["vp_enable_registration"]));
    vp_updateoption("enable_beneficiaries", trim($_REQUEST["enable_beneficiaries"]));
    vp_updateoption("vp_template", trim($_REQUEST["template"]));
    vp_updateoption("vtu_timeout", trim($_REQUEST["vtu_timeout"]));
    vp_updateoption("hide_why", trim($_REQUEST["hide_why"]));
    vp_updateoption("resc", trim($_REQUEST["upgradeamt"]));
    vp_updateoption("vp_redirect", trim($_REQUEST["vpredirect"]));
    vp_updateoption("wplogin_redirect", trim($_REQUEST["wplogin_redirect"]));
    vp_updateoption("vp_phone_line", trim($_REQUEST["vpphone"]));
    vp_updateoption("vp_whatsapp", trim($_REQUEST["vpwhatsapp"]));
    vp_updateoption("vp_whatsapp_group", trim($_REQUEST["vpwhatsappg"]));
    vp_updateoption("allow_crypto", trim($_REQUEST["allow_crypto"]));
    vp_updateoption("allow_cards", trim($_REQUEST["allow_cards"]));
    vp_updateoption("totcons", trim($_REQUEST["totcons"]));
    vp_updateoption("charge_method", trim($_REQUEST["charge_method"]));
    vp_updateoption("charge_back", trim($_REQUEST["chargeback"]));
    vp_updateoption("minimum_amount_fundable", trim($_REQUEST["minimum_amount_fundable"]));
    
    //Emails Nd Auto Refund
    if(is_plugin_active('vprest/vprest.php') && vp_getoption("resell") == "yes" ){
    vp_updateoption("auto_refund", trim($_REQUEST["auto_refund"]));
    vp_updateoption("email_verification", trim($_REQUEST["email_verification"]));
    vp_updateoption("email_transaction", trim($_REQUEST["email_transaction"]));
    vp_updateoption("email_transfer", trim($_REQUEST["email_transfer"]));
    vp_updateoption("email_withdrawal", trim($_REQUEST["email_withdrawal"]));
    vp_updateoption("email_kyc", trim($_REQUEST["email_kyc"]));

    if(is_plugin_active('vpmlm/vpmlm.php') ){
    vp_updateoption("id_on_reg", trim($_REQUEST["id_on_reg"]));
    }
    }

    



    vp_updateoption("enablehollatag", trim($_REQUEST["enablehollatag"]));
    vp_updateoption("hollatagcompany", trim($_REQUEST["hollatagcompany"]));
    vp_updateoption("hollatagusername", trim($_REQUEST["hollatagusername"]));
    vp_updateoption("hollatagpassword", trim($_REQUEST["hollatagpassword"]));
    vp_updateoption("hollatagservices", trim($_REQUEST["hollatagservices"]));
    vp_updateoption("vpwalm", trim($_REQUEST["message"]));
    vp_updateoption("show_notify", trim($_REQUEST["show_notify"]));
    vp_updateoption("manual_funding", trim($_REQUEST["fundmessage"]));

    
    if(is_plugin_active("vprest/vprest.php")){

        vp_updateoption("allow_withdrawal", trim($_REQUEST["allow_withdrawal"]));
        vp_updateoption("allow_to_bank", trim($_REQUEST["allow_to_bank"]));
        vp_updateoption("wallet_to_wallet", trim($_REQUEST["wallettowallet"]));
        vp_updateoption("minimum_amount_transferable", trim($_REQUEST["minimum_amount_transferable"]));
    

    }
    
    die('{"status":"100"}');
    
}?>