<?php
header("Access-Control-Allow-Origin: 'self'");
//header("Access-Control-Allow-Methods: POST, GET");
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
}
else{
include_once(ABSPATH ."wp-load.php");
}

if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH.'wp-admin/includes/plugin.php');
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');


if(isset($_POST['updatefl'])){

    vp_updateoption('ppub', $_POST['ppublic']);
    vp_updateoption('psec', $_POST['psecret']);

    vp_updateoption('monnifytestmode', $_POST['monnifytest']);
    vp_updateoption('monnifyapikey', $_POST['mapi']);
    vp_updateoption('monnifysecretkey', $_POST['msec']);
    vp_updateoption('monnifycontractcode', $_POST['mcontract']);
    vp_updateoption('allow_card_method', $_POST['allow_card_method']);
    vp_updateoption('paychoice', $_POST['paychoice']);
    
    
die('{"status":"100"}');
}?>