<?php
    if( $_GET["subpage"] == "paymentgateway"){

        echo"
        <div class=\"card col\">
              <div class=\"card-body\">
                  <h5 class=\"card-title\">Payment Gateway</h5>
                  <div class=\"table-responsive\">
    <div class='payment_gateway'>

    <form method='post' target='_SELF' class='updatefl'>

    <div class='input-group mb-3'>
    <span class='input-group-text'>Webhook</span>
    <input type='text' name='webhook' value='".vp_getoption('siteurl')."/wp-content/plugins/vtupress/index.php' readOnly class='form-control' >
    </select>
    </div>

    <div class='mb-3'>
    <label>Select Your Prefered Payment Gateway</label>
    <select name='paychoice' class='form-select payment-opt' >
    <option value='".vp_getoption('paychoice')."'>".vp_getoption('paychoice')."</option>
    <option value='paystack'>PayStack</option>
    <option value='monnify'>Monnify</option>
    </select>
    </div>


    <!--PAYSTACK -->
<div class='container'>
<h4 class='paystack'>Paystack</h4>
<h4 class='monnify'>Monnify</h4>
<div class='p-2'>

<div class='paystack'>
    <div class='mb-3'>
    <label for='ppublickey' class='form-label'>PayStack Public Key</label><br>
    <input type='text' class='form-control' name='ppublic'value='".vp_getoption('ppub')."'><br>
    <label for='secretkey'>PayStack SecretKey</label><br>
    <input type='text' class='form-control' name='psecret' value='".vp_getoption('psec')."'><br>
    </div>
</div>


    <!-- MONNIFY -->
 
    <div class='monnify'>
    <div class='mb-3'>
    <label for='ppublickey' class='form-label'>Monnify Api Key</label><br>
    <input type='text' class='form-control' name='mapi'value='".vp_getoption('monnifyapikey')."'><br>
    
    <label for='psecretkey' class='form-label'>Monnify Secret Key</label><br>
    <input type='text' class='form-control' name='msec'value='".vp_getoption('monnifysecretkey')."'><br>
    
    <label for='secretkey' class='form-label' >Monnify ContractCode</label><br>
    <input type='text' class='form-control' name='mcontract' value='".vp_getoption('monnifycontractcode')."'><br>
    
    <label for='secretkey' class='form-label'>Monnify Test Mode</label><br>
    Please Do Not Choose 'True' To This When You Entered A Live Secret Api Key & Api Key<br>
    
    <div class='form-group'>
    <select name='monnifytest' class='form-select group-text'>
    <option value='".vp_getoption('monnifytestmode')."'>".vp_getoption('monnifytestmode')."</option>
    <option value='true'>True</option>
    <option value='false'>False</option>
    </select>
    ";
    
    if(vp_getoption('monnifytestmode') == "false" && (empty(stripos(vp_getoption('monnifyapikey'),"test")) || stripos(vp_getoption('monnifyapikey'),"test") === false ) && vp_getoption("paychoice") == "monnify"){
        echo"
    <input type='button' class='group-text run-dan btn btn-primary visibility-none d-none' value='Run Dedicated Account Number'>
    ";
    }
    ?>
    <!--SCRIPT FOR DAN -->
    <script>
    jQuery(".run-dan").click(function(){
    
var obj = {};
      swal({
  title: "Processing...",
  text: "You wanna (re)run DAN for?",
  icon: "warning",
  buttons: {
    cancel: "Close",
    confirm: "Those Without DAN",
    roll: {
      text: "All Users",
      value: "all",
    },
  },
}).then((value) => {
var dot = "no";
if(value == true){ //if confirm clicked then Those without DAN

obj["dan_for"] = "few";
dot = "yes";
}else if(value == "null"){ //if close clicked then return/close
return;
}
else if(value == "all"){ // if success clicked
  obj["dan_for"] = "all";
  dot = "yes";
}
else{
  return;
}


  
if(dot == "yes"){
     jQuery(".preloader").show();
      
    obj["rundan"] = "run";
    jQuery.ajax({
      url: '<?php echo esc_url(plugins_url('vtupress/rundan.php'));?>',
      data: obj,
     dataType: 'text',
      'cache': false,
      "async": true,
      error: function (jqXHR, exception) {
           jQuery(".preloader").hide();
            var msg = "";
            if (jqXHR.status === 0) {
                msg = "No Connection. Verify Network.";
         swal({
      title: "Error!",
      text: msg,
      icon: "error",
      button: "Okay",
    });
      
            }  else if (jqXHR.status == 403) {
            msg = "Access Forbidden [403].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }else if (jqXHR.status == 404) {
                msg = "Requested page not found. [404]";
                 swal({
      title: "Error!",
      text: msg,
      icon: "error",
      button: "Okay",
    });
            } else if (jqXHR.status == 500) {
                msg = "Internal Server Error [500].";
                 swal({
      title: "Error!",
      text: msg,
      icon: "error",
      button: "Okay",
    });
            } else if (exception === "parsererror") {
                msg = "Requested JSON parse failed.";
                   swal({
      title: msg,
      text: jqXHR.responseText,
      icon: "error",
      button: "Okay",
    });
            } else if (exception === "timeout") {
                msg = "Time out error.";
                 swal({
      title: "Error!",
      text: msg,
      icon: "error",
      button: "Okay",
    });
            } else if (exception === "abort") {
                msg = "Ajax request aborted.";
                 swal({
      title: "Error!",
      text: msg,
      icon: "error",
      button: "Okay",
    });
            } else {
                msg = "Uncaught Error." + jqXHR.responseText;
                 swal({
      title: "Error!",
      text: msg,
      icon: "error",
      button: "Okay",
    });
            }
        },
      
      success: function(data) {
           jQuery(".preloader").hide();
            if(data == "100"){
              swal({
      title: "Successful",
      text: "Users Without A DAN Has Successfully Goten A Virtual Account Number",
      icon: "success",
      button: "Okay",
    }).then((value) => {
        location.reload();
    });
          }
          else{
              jQuery(".preloader").hide();
        swal({
      buttons: {
        cancel: "Why?",
        defeat: "Okay",
      },
      title: "Failed",
      text: "Click \'Why\' To See reason",
      icon: "error",
    })
    .then((value) => {
      switch (value) {
     
        case "defeat":
          break;
        default:
          swal(data, {
          icon: "info",
        });
      }
    });
          }
      },
      type: 'POST'
    });
    
  }

});

    });


     
    </script>

    <!-- END OF DAN SCRIPT -->
    <?php
    echo"
    </div>
    
    </div>

    </div>
<!--END OF MONNIFY -->


<div class='mb-3'>
<label>Allow Card Funding Payment Method</label>
<select name='allow_card_method' class='form-select' >
<option value='".vp_getoption('allow_card_method')."'>".vp_getoption('allow_card_method')."</option>
<option value='yes'>YES</option>
<option value='no'>No</option>
</select>
</div>

    </div>
    </div>
    
    
    ";
    
    
    echo '
    <input type="button" name="updatefl" value="Save" class="btn btn-primary updatef2">
    </form>
    
    <script>

    var popt = jQuery(".payment-opt").val();
    if(popt == "paystack"){
      jQuery(".monnify").hide();
      jQuery(".paystack").show();
    }
    else if(popt == "monnify"){
      jQuery(".monnify").show();
      jQuery(".paystack").hide();
    }
  
    jQuery(".payment-opt").on("change",function(){
  
      var popt = jQuery(".payment-opt").val();
      if(popt == "paystack"){
        jQuery(".monnify").hide();
        jQuery(".paystack").show();
      }
      else if(popt == "monnify"){
        jQuery(".monnify").show();
        jQuery(".paystack").hide();
      }
  
    });
  
  

    jQuery(".updatef2").on("click",function(){
        jQuery(".preloader").show();
   var obj = {};
   var toatl_input = jQuery(".updatefl input, .updatefl select, .updatefl textarea").length;
   var run_obj;
   
   for(run_obj = 0; run_obj <= toatl_input; run_obj++){
   var current_input = jQuery(".updatefl input, .updatefl select, .updatefl textarea").eq(run_obj);
   
   
   var obj_name = current_input.attr("name");
   var obj_value = current_input.val();
   
   if(typeof obj_name !== typeof undefined && obj_name !== false){
   obj[obj_name] = obj_value;
   }

        
   }
   
   jQuery.ajax({
     url: "'.esc_url(plugins_url('vtupress/admin/pages/settings/saves/paychoice.php')).'",
     data: obj,
     dataType: "json",
     "cache": false,
     "async": true,
     error: function (jqXHR, exception) {
          jQuery(".preloader").hide();
           var msg = "";
           if (jqXHR.status === 0) {
               msg = "No Connection. Verify Network.";
        swal({
     title: "Error!",
     text: msg,
     icon: "error",
     button: "Okay",
   });
     
           }  else if (jqXHR.status == 403) {
            msg = "Access Forbidden [403].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 404) {
               msg = "Requested page not found. [404]";
                swal({
     title: "Error!",
     text: msg,
     icon: "error",
     button: "Okay",
   });
           } else if (jqXHR.status == 500) {
               msg = "Internal Server Error [500].";
                swal({
     title: msg,
     text: jqXHR.responseText,
     icon: "error",
     button: "Okay",
   });
           } else if (exception === "parsererror") {
               msg = "Requested JSON parse failed!";
                  swal({
     title: msg,
     text: jqXHR.responseText,
     icon: "error",
     button: "Okay",
   });
           } else if (exception === "timeout") {
               msg = "Time out error.";
                swal({
     title: "Error!",
     text: msg,
     icon: "error",
     button: "Okay",
   });
           } else if (exception === "abort") {
               msg = "Ajax request aborted.";
                swal({
     title: "Error!",
     text: msg,
     icon: "error",
     button: "Okay",
   });
           } else {
               msg = "Uncaught Error." + jqXHR.responseText;
                swal({
     title: "Error!",
     text: msg,
     icon: "error",
     button: "Okay",
   });
           }
       },
     success: function(data) {
        jQuery(".preloader").hide();
           if(data.status == "100" ){
       
             swal({
     title: "SAVED",
     text: "Update Completed",
     icon: "success",
     button: "Okay",
   }).then((value) => {
       location.reload();
   });
         }
         else{
             
        jQuery(".preloader").hide();
        swal({
     title: "Error",
     text: "Saving Wasn\"t Successful",
     icon: "error",
     button: "Okay",
   });
         }
     },
     type: "POST"
   });
   
   });
   
   
   </script>
   
    </div>
    </div>
    </div>
    </div>
    ';

}?>