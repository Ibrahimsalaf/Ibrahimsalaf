<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
}
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");

if(isset($_POST["userid"])){
    //global $wp_query;
    $ddid = $_POST["userid"];

    
    switch($_POST["action"]){
        case"mban":
global $wpdb;
            $hid = explode(",", $ddid);
            foreach($hid as $hd){
                if(!empty($hd)){
                    vp_updateuser($hd,'vp_user_access',"ban");
                    $data = [ 'vp_ban' => "ban" ];
                    $where = [ 'id' => $hd ];
                    $updated = $wpdb->update( $wpdb->prefix.'users', $data, $where);
                        
                }
            }
die("100");
        break;
        case"munban":
            global $wpdb;
            $hid = explode(",", $ddid);
            foreach($hid as $hd){
                if(!empty($hd)){
                    vp_updateuser($hd,'vp_user_access',"access");
                    $data = [ 'vp_ban' => "access" ];
                    $where = [ 'id' => $hd ];
                    $updated = $wpdb->update( $wpdb->prefix.'users', $data, $where);
                        
                }
            }
die("100");

        break;
        case"mrundan":
            global $wpdb;
            $hid = explode(",", $ddid);

    if(vp_getoption('paychoice') == "monnify"){

            foreach($hid as $hd){
                if(!empty($hd)){
                    $userid = $hd;
                   $username = get_userdata($hd)->user_login;
                   $email = get_userdata($hd)->user_email;
                   $fun = vp_getuser($hd,"first_name",true);
                   $lun = vp_getuser($hd,"last_name",true);

                   
	
                        if(vp_getoption('monnifytestmode') == "true" ){
                            $baseurl =  "https://sandbox.monnify.com";
                            $mode = "test";
                        }
                        else{
                            $baseurl =  "https://api.monnify.com";
                            $mode = "live";
                        }
                            
                        
                        $apikeym = vp_getoption("monnifyapikey");
                        $secretkeym = vp_getoption("monnifysecretkey");
                        
                        $curl = curl_init();
                        
                        curl_setopt_array($curl, array(
                          CURLOPT_URL => $baseurl.'/api/v1/auth/login/',
                          CURLOPT_RETURNTRANSFER => true,
                          CURLOPT_ENCODING => '',
                          CURLOPT_MAXREDIRS => 10,
                          CURLOPT_TIMEOUT => 0,
                          CURLOPT_FOLLOWLOCATION => true,
                          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                          CURLOPT_CUSTOMREQUEST => 'POST',
                          CURLOPT_HTTPHEADER => [
                                    "Content-Type: application/json",
                                    "Authorization: Basic ".base64_encode("$apikeym:$secretkeym") 
                                ],
                        ));
                        
                        $respo = curl_exec($curl);
                        
                        $json = json_decode($respo)->responseBody->accessToken;
                        
                        
                        $curl = curl_init();
                        $code = rand(1000,100000);
                        curl_setopt_array($curl, array(
                          CURLOPT_URL => $baseurl.'/api/v2/bank-transfer/reserved-accounts',
                          CURLOPT_RETURNTRANSFER => true,
                          CURLOPT_ENCODING => '',
                          CURLOPT_MAXREDIRS => 10,
                          CURLOPT_TIMEOUT => 0,
                          CURLOPT_FOLLOWLOCATION => true,
                          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                          CURLOPT_CUSTOMREQUEST => 'POST',
                          CURLOPT_POSTFIELDS =>'{
                            "accountReference": "'.$code.'",
                            "accountName": "'.$username.'",
                            "currencyCode": "NGN",
                            "contractCode": "'. vp_getoption("monnifycontractcode").'",
                            "customerEmail": "'.$email.'",
                            "customerName": "'.$fun." ".$lun.'",
                            "getAllAvailableBanks": false,
                            "preferredBanks": ["035","232","50515"]
                            
                        }',
                          CURLOPT_HTTPHEADER => array(
                            "Authorization: Bearer $json",
                            'Content-Type: application/json'
                          ),
                        ));
                        
                        $respon = curl_exec($curl);
                        
                        curl_close($curl);
                        
                        $response = json_decode($respon,true);
                        
                        $reference = $response["responseBody"]["accountReference"];
                        $customerName = $response["responseBody"]["accounts"][0]["accountName"];
                        $accountNumber = $response["responseBody"]["accounts"][0]["accountNumber"];
                        $bankName = $response["responseBody"]["accounts"][0]["bankName"];
                        
                        vp_updateuser($userid,"bank_reference",$reference);
                        vp_updateuser($userid,"account_mode",$mode);
                        
                        vp_updateuser($userid,"account_name",$customerName);
                        vp_updateuser($userid,"account_number",$accountNumber);
                        vp_updateuser($userid,"bank_name",$bankName);
                        
                        if(isset($response["responseBody"]["accounts"][1]["accountName"])){
                          $customerName = $response["responseBody"]["accounts"][1]["accountName"];
                          $accountNumber = $response["responseBody"]["accounts"][1]["accountNumber"];
                          $bankName = $response["responseBody"]["accounts"][1]["bankName"];
                        
                        vp_updateuser($userid,"account_name1",$customerName);
                        vp_updateuser($userid,"account_number1",$accountNumber);
                        vp_updateuser($userid,"bank_name1",$bankName);
                        
                          }
                          else{}
                        
                          
                          if(isset($response["responseBody"]["accounts"][2]["accountName"])){
                            $customerName = $response["responseBody"]["accounts"][2]["accountName"];
                            $accountNumber = $response["responseBody"]["accounts"][2]["accountNumber"];
                            $bankName = $response["responseBody"]["accounts"][2]["bankName"];
                        
                        vp_updateuser($userid,"account_name2",$customerName);
                        vp_updateuser($userid,"account_number2",$accountNumber);
                        vp_updateuser($userid,"bank_name2",$bankName);
                        
                            }
                            else{}
                        
                        }                        




                }

                die("100");
    }else{
        die("ONLY MONNIFY USERS CAN GENERATE ACCOUNT NUMBERS TO CUSTOMERS");
    }


        break;
        case"changepin":
            $pin = $_POST["pin"];
            vp_updateuser($ddid, "vp_pin", $pin);
            die('{"status":"100"}') ;
        break;
        case"changephone":
            $phone = $_POST["phone"];
            vp_updateuser($ddid, "vp_phone", $phone);
            die('{"status":"100"}') ;
        break;
        case"changeemail":
            $email = $_POST["usemail"];
            if(!email_exists($email)){
                $args = array(
                    'ID'         => $ddid,
                    'user_email' => esc_attr($email)
                );            
            wp_update_user( $args );
                die('{"status":"100"}') ;
            }
            else{
                die('{"status":"101"}');
            }
               
            break;
        case"userban":
            vp_updateuser(intval($_POST["userid"]),'vp_user_access',"ban");
            $data = [ 'vp_ban' => "ban" ];
            $where = [ 'id' => $ddid ];
            $updated = $wpdb->update( $wpdb->prefix.'users', $data, $where);
                echo '{"status":"100"}';
            break;
   case"useraccess":
   vp_updateuser(intval($_POST["userid"]),'vp_user_access',"access");
   $data = [ 'vp_ban' => "access" ];
   $where = [ 'id' => $ddid ];
   $updated = $wpdb->update( $wpdb->prefix.'users', $data, $where);
       echo '{"status":"100"}';
   break;
   case "addbalance":
    
    $amount = floatval($_POST["amount"]);
             $useramount = vp_getuser(intval($_POST["userid"]), 'vp_bal', true);
              $balsum = floatval($useramount ) + floatval($_POST["amount"]);
             
          
  
  if($balsum > $useramount){
      
      $updated_user = vp_updateuser(intval($_POST["userid"]),'vp_bal', floatval($balsum));
      
      if($updated_user == true || $updated_user == "true" || $updated_user == "1"){

        $descriptionw = $_POST["reason"];
        if(!empty($descriptionw)){
      $description = $_POST["reason"];	
        }
       else{
      $description =  "Credited By Admin"; 
       }
      
              
      global $wpdb;
      $name = "Admin";
      
      $fund_amount = $_POST["amount"];
      $before_amount = $useramount;
      $now_amount = $balsum;
      $user_id = $_POST["userid"];
      $the_time = current_time('mysql', 1);
      
      $table_name = $wpdb->prefix.'vp_wallet';
      $wpdb->insert($table_name, array(
      'name'=> $name,
      'type'=> "Wallet",
      'description'=> $description,
      'fund_amount' => $fund_amount,
      'before_amount' => $before_amount,
      'now_amount' => $now_amount,
      'user_id' => $user_id,
      'status' => "Approved",
      'the_time' => date('Y-m-d h:i:s A')
      ));
      
      die('{"status":"100"}');
  }
  else{
      
      die('{"status":"200"}');
  }
  
  }
  


    break;
    case"verify_user":
    
    vp_updateuser($ddid,"email_verified","verified");
    
    //echo vp_getuser($ddid,"email_verified");
    echo '{"status":"100"}';
    
    break;
    case "removebalance":
        
    $amount = floatval($_POST["amount"]);
              $useramount = vp_getuser(intval($_POST["userid"]), 'vp_bal', true);
      
              $balsum = floatval($useramount ) - floatval($_POST["amount"]);
              
              
          
  if($balsum < $useramount){
      
      $updated_user = vp_updateuser(intval($_POST["userid"]),'vp_bal', floatval($balsum));
      
      if($updated_user == true || $updated_user == "true" || $updated_user == "1"){

        $descriptione = $_POST["reason"];
        if(!empty($descriptione)){
      $description = $_POST["reason"];	
        }
       else{
      $description =  "Debited By Admin"; 
       }
      
      
                
      global $wpdb;
      $name = "Admin";
      $fund_amount = $_POST["amount"];
      $before_amount = $useramount;
      $now_amount = $balsum;
      $user_id = $_POST["userid"];
      $the_time = current_time('mysql', 1);
      
      $table_name = $wpdb->prefix.'vp_wallet';
      $wpdb->insert($table_name, array(
      'name'=> $name,
      'type'=> "Wallet",
      'description'=> $description,
      'fund_amount' => $fund_amount,
      'before_amount' => $before_amount,
      'now_amount' => $now_amount,
      'user_id' => $user_id,
      'status' => "Approved",
      'the_time' => date('Y-m-d h:i:s A')
      ));
      
    
      
      die('{"status":"100"}');
  }
  else{
      
     die('{"status":"200"}');
  }
  }
  
  

    break;
    case "setbalance":
        
    $amount = floatval($_POST["amount"]);
              $useramount = vp_getuser(intval($_POST["userid"]), 'vp_bal', true);
   
               
      
      $updated_user = vp_updateuser(intval($_POST["userid"]),'vp_bal', floatval($_POST["amount"]));
      
      if($updated_user == true || $updated_user == "true" || $updated_user == "1"){

          
   $descriptione = $_POST["reason"];
   if(!empty($descriptione)){
 $description = $_POST["reason"];	
   }
  else{
 $description =  "Credited By Admin"; 
  }
 
 
 global $wpdb;
 $name = "Admin";
 $fund_amount = $_POST["amount"];
 $before_amount = $useramount;
 $now_amount = floatval($_POST["amount"]);
 $user_id = $_POST["userid"];
 $the_time = current_time('mysql', 1);
 
 $table_name = $wpdb->prefix.'vp_wallet';
 $wpdb->insert($table_name, array(
 'name'=> $name,
 'type'=> "Wallet",
 'description'=> $description,
 'fund_amount' => $fund_amount,
 'before_amount' => $before_amount,
 'now_amount' => $now_amount,
 'user_id' => $user_id,
 'status' => "Approved",
 'the_time' => date('Y-m-d h:i:s A')
 ));

      
     die('{"status":"100"}');
  }
  else{
      
      die('{"status":"200"}');
  }
  

    break;
    case "changeplan":
  
        $plan = $_POST["plan"];
        $vrid = $_POST["apikey"];
  
       $updated_user = vp_updateuser(intval($_POST["userid"]),'vr_plan', $_POST["plan"]);
       
  $apikey = vp_getuser($_POST["userid"],'vr_id',true);
  if( empty($apikey) || strtolower($apikey) == "null" || $apikey === "0" || $apikey != $_POST["apikey"] ){
  $updated_user1 = vp_updateuser($_POST["userid"], 'vr_id',$_POST["apikey"]);
  }
  else{
      $updated_user1 = true;
  }
  
       if($updated_user == true || $updated_user == "true" || $updated_user == "1" && ($updated_user1 == true || $updated_user1 == "true" || $updated_user1 == "1")){
      
      echo '{"status":"100"}';
  }
  else{
      
      echo '{"status":"200"}';
  } 

      break;
    case "switchto":
  $admin_id = get_current_user_id();
  $id = $_POST["userid"];
  $cookie_name = "switchto";
  //$cookie_value = get_userdata($id)->user_login;
  //$cookie_id = $id;
  setcookie($cookie_name, $admin_id, time() + (86400 * 30), "/"); // + 30 Days
  
           wp_clear_auth_cookie();
           wp_set_current_user($id);
           wp_set_auth_cookie($id, true);
  //$redirect_to = $_SERVER['REQUEST_URI'];
  
  die('{"status":"100"}');
  
    break;
    case "none":
  
    break;
  
      }
  
}?>