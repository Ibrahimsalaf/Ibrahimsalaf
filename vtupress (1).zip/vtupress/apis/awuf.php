<?php

if(!isset($_SERVER['HTTP_REFERER'])){
	
	die();
}
else{
	
}
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
}
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH ."wp-load.php");
include_once(ABSPATH.'wp-admin/includes/plugin.php');
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
$vpdebug = vp_getoption("vpdebug");

if(isset($_POST)){


vp_updateoption('awufresponse_id',$_REQUEST["awufresponse_id"]);
vp_updateoption("awufquerytext",$_REQUEST["awufquerytext"]);
vp_updateoption("awufquerymethod",$_REQUEST["awufquerymethod"]);
vp_updateoption("awufaddendpoint",$_REQUEST["awufaddendpoint"]);


///////////////////////////////AWUF AIRTIME UPDATE////////////////////////////////
vp_updateoption("wairtimebaseurl",$_REQUEST["wairtimebaseurl"]);
vp_updateoption("wairtimeendpoint",$_REQUEST["wairtimeendpoint"]);
vp_updateoption("wairtimerequest",$_REQUEST["wairtimerequest"]);
vp_updateoption("wairtimerequesttext",$_REQUEST["wairtimerequesttext"]);
vp_updateoption("wairtimesuccesscode",$_REQUEST["wairtimesuccesscode"]);
vp_updateoption("wairtimesuccessvalue",$_REQUEST["wairtimesuccessvalue"]);
vp_updateoption("wairtimesuccessvalue2",$_REQUEST["wairtimesuccessvalue2"]);

vp_updateoption("warequest_id",$_REQUEST["warequest_id"]);

for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("wairtimehead".$cheaders,$_REQUEST["wairtimehead".$cheaders]);
vp_updateoption("wairtimevalue".$cheaders,$_REQUEST["wairtimevalue".$cheaders]);
}

vp_updateoption("wairtimeaddpost",$_REQUEST["wairtimeaddpost"]);


for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("wairtimepostdata".$cpost,$_REQUEST["wairtimepostdata".$cpost]);
vp_updateoption("wairtimepostvalue".$cpost,$_REQUEST["wairtimepostvalue".$cpost]);
}

vp_updateoption("wairtimeamountattribute",$_REQUEST["wairtimeamountattribute"]);
vp_updateoption("wairtimephoneattribute",$_REQUEST["wairtimephoneattribute"]);
vp_updateoption("wairtimenetworkattribute",$_REQUEST["wairtimenetworkattribute"]);
vp_updateoption("wairtimemtn",$_REQUEST["wairtimemtn"]);
vp_updateoption("wairtimeglo",$_REQUEST["wairtimeglo"]);
vp_updateoption("wairtime9mobile",$_REQUEST["wairtime9mobile"]);
vp_updateoption("wairtimeairtel",$_REQUEST["wairtimeairtel"]);

/////////////////////////////////////////////////////////////////////////////

for($awufaddheaders=1; $awufaddheaders<=4; $awufaddheaders++){
    vp_updateoption("awufaddheaders".$awufaddheaders,$_REQUEST["awufaddheaders".$awufaddheaders]);
    vp_updateoption("awufaddvalue".$awufaddheaders,$_REQUEST["awufaddvalue".$awufaddheaders]);
}

vp_updateoption("airtime_head3",$_REQUEST["airtimehead3"]);
vp_updateoption("airtime3_response_format",$_REQUEST["airtimeresponse3"]);
vp_updateoption("airtime3_response_format_text",$_REQUEST["airtimeresponsetext3"]);


die("100");

}
?>