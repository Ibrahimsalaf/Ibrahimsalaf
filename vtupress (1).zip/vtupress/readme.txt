=== Your Plugin Name ===
Contributors: vtupress
Tags: vtupress, vtu plugin, vtu theme, vtu plugin for wordpress
Requires at least: 7.3
Tested up to: 5.9.2
Stable tag: 2.0.8
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl.html
 
A WordPress plugin to setup a vtu website, vtu portal and likes.
 
== Description ==
 
This simple plugin is a good solution to vtu scripts which are somewhat problematic. Vtupress provides solution to fast and secured vtu site.
However, a free account on vtupress is required to get it work by activation. Account is free to get on vtupress.com.
Unlike other vtu scripts, vtupress provides contant stable updates to improve your business flexibility. Could connect to any vtu vendor in Nigeria via their *API* which is required
to run vtu services easily from your wordpress website!
 
== Installation ==
 
1. Upload the plugin folder to your /wp-content/plugins/ folder.
2. Go to the **Plugins** page and activate the plugin.
 
== Frequently Asked Questions ==
 
= How do I use this plugin? =
 
All you need is a vtupress activation key which is free on vtupress.com, a vendor, a payment gateway such as flutterwave - monnify - paystack (as preferred).
 
= How to uninstall the plugin? =
 
Simply deactivate and delete the plugin. 
 
== Screenshots ==
1. Description of the first screenshot. 
1. Description of the second screenshot. 
 
== Changelog ==
= 2.0.8=
* Plugin Uploaded. 